class ProceduresPerformed:
    def __init__(self, procedure):
        self._procedure = procedure

    def get_procedure(self):
        return self._procedure

    def set_procedure(self, procedure):
        self._procedure = procedure
